﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day32_Mid
{
    class Program
    {
        static void Main(string[] args)
        {
            MydbMid db = new MydbMid();

            int ch, id;

            do
            {
                Console.WriteLine("1 INSERT RECORD");
                Console.WriteLine("2 DISPLAY RECORD");
                Console.WriteLine("3 UPDATE RECORD");
                Console.WriteLine("4 SEARCH RECORD");
                Console.WriteLine("5 DELETE RECORD");
                Console.WriteLine("6 EXIT");

                ch = int.Parse(Console.ReadLine());

                Product ob = new Product();
                switch (ch)
                {
                    case 1:
                        Console.Write("Product id       = ");
                        ob.Pid = int.Parse(Console.ReadLine());
                        Console.Write("Product name      = ");
                        ob.Pname = Console.ReadLine();
                        Console.Write("Price       = ");
                        ob.Price = int.Parse(Console.ReadLine());
                        Console.Write("Category id   = ");
                        ob.Cid = int.Parse(Console.ReadLine());
                        Console.WriteLine();
                        db.Products.Add(ob);
                        db.SaveChanges();
                        break;
                    case 2:
                        foreach (Product p in db.Products)
                        {
                            Console.Write(p.Pid + "\t");
                            Console.Write(p.Pname + "\t");
                            Console.Write(p.Price + "\t");
                            Console.Write(p.Cid + "\t");
                            

                            Console.WriteLine();
                        }
                        break;
                    case 3:
                        Console.Write("Product id      = ");
                        id = int.Parse(Console.ReadLine());

                        ob = db.Products.Find(id);

                        if (ob == null)
                            Console.WriteLine("Cannot update as the id not found");
                        else
                        {
                            Console.Write("Product id       = ");
                            ob.Pid = int.Parse(Console.ReadLine());
                            Console.Write("Product name      = ");
                            ob.Pname = Console.ReadLine();
                            Console.Write("Price       = ");
                            ob.Price = int.Parse(Console.ReadLine());
                            Console.Write("Category id   = ");
                            ob.Cid = int.Parse(Console.ReadLine());
                            Console.WriteLine();

                            db.SaveChanges();

                        }



                        break;
                    case 4:
                        Console.Write("Product id       = ");
                        id = int.Parse(Console.ReadLine());

                        ob = db.Products.Find(id);

                        if (ob == null)
                            Console.WriteLine("Cannot find the record for given id = " + id);
                        else
                        {
                            Console.WriteLine("Product name     = " + ob.Pname);
                            Console.WriteLine("Price        = " + ob.Price);
                            Console.WriteLine("Cid  = " + ob.Cid);
                        }
                        break;
                    case 5:
                        Console.Write("Product id       = ");
                        id = int.Parse(Console.ReadLine());

                        ob = db.Products.Find(id);

                        if (ob == null)
                            Console.WriteLine("Cannot find the record for given id = " + id);
                        else
                        {
                            db.Products.Remove(ob);
                            Console.WriteLine("Data entry is deleted");
                            db.SaveChanges();
                        }
                        break;
                    case 6:
                        break;
                    default:Console.WriteLine("Invalid Choice");
                            break;
                }
            } while (ch != 6);
        }
    }
}
